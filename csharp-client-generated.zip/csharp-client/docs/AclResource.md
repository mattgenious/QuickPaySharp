# IO.Swagger.Model.AclResource
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountType** | **string** | Account type that this resource applies to | [optional] 
**Actions** | **List&lt;string&gt;** | The valid http verbs for this resource | [optional] 
**Description** | **string** | Description of the resource | [optional] 
**Resource** | **string** | Path to the resource | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

