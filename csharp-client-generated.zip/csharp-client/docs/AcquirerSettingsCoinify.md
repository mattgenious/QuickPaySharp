# IO.Swagger.Model.AcquirerSettingsCoinify
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**ApiKey** | **string** | Coinify API key | [optional] 
**ApiSecret** | **string** | Coinify API secret | [optional] 
**IpnSecret** | **string** | Coinify IPN secret | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

