# IO.Swagger.Model.AcquirerSettingsMobilePay
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**DeliveryLimitedTo** | **string** | MobilePay delivery address selection countries limited to | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

