# IO.Swagger.Model.AcquirerSettingsResurs
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**CustomerId** | **string** | Resurs user_name | [optional] 
**CustomerPassword** | **string** | Resurs password | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

