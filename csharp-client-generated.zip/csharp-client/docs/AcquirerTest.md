# IO.Swagger.Model.AcquirerTest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Details** | [**AcquirerTestDetails**](AcquirerTestDetails.md) | Test result details | [optional] 
**Success** | **bool?** | All tests successful? | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

