# IO.Swagger.Model.AcquirerTestDetails
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_3dSecure** | [**AcquirerTestResult**](AcquirerTestResult.md) | 3d_secure test status | [optional] 
**Dankort** | [**AcquirerTestResult**](AcquirerTestResult.md) | dankort test status | [optional] 
**Diners** | [**AcquirerTestResult**](AcquirerTestResult.md) | diners test status | [optional] 
**Fbg1886** | [**AcquirerTestResult**](AcquirerTestResult.md) | fbg1886 test status | [optional] 
**Mastercard** | [**AcquirerTestResult**](AcquirerTestResult.md) | mastercard test status | [optional] 
**Recurring** | [**AcquirerTestResult**](AcquirerTestResult.md) | recurring test status | [optional] 
**Visa** | [**AcquirerTestResult**](AcquirerTestResult.md) | visa test status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

