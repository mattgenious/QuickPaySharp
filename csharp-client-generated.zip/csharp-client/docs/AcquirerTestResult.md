# IO.Swagger.Model.AcquirerTestResult
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currency** | **string** | Tested currency | [optional] 
**Message** | **string** | Test message | [optional] 
**Success** | **bool?** | Test successful? | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

