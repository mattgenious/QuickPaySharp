# IO.Swagger.Model.Address
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Att** | **string** | Att. | [optional] 
**City** | **string** | City | [optional] 
**CountryCode** | **string** | Country code | [optional] 
**Name** | **string** | Name | [optional] 
**Region** | **string** | Region | [optional] 
**Street** | **string** | Street | [optional] 
**VatNo** | **string** | VAT reg. no. | [optional] 
**ZipCode** | **string** | Zip code | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

