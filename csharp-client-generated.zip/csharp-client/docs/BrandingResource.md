# IO.Swagger.Model.BrandingResource
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Data** | **string** | Binary data encoded in Base64 | [optional] 
**Mime** | **string** | Mime type | [optional] 
**Name** | **string** | Name | [optional] 
**Size** | **string** | Size in bytes | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

