# IO.Swagger.Model.IntegrationSettingsEconomic
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the settings are active | [optional] 
**Agreement** | **string** | e-conomic agreement id | [optional] 
**AgreementToken** | **string** | e-conomic agreement grant token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

