# IO.Swagger.Model.OptionalAddress
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Att** | **string** | Att. | [optional] 
**City** | **string** | City | [optional] 
**CompanyName** | **string** | Company name | [optional] 
**CountryCode** | **string** | Country code | [optional] 
**Email** | **string** | E-mail address | [optional] 
**HouseExtension** | **string** | House extension | [optional] 
**HouseNumber** | **string** | House number | [optional] 
**MobileNumber** | **string** | Mobile number | [optional] 
**Name** | **string** | Name | [optional] 
**PhoneNumber** | **string** | Phone number | [optional] 
**Region** | **string** | Region | [optional] 
**Street** | **string** | Street | [optional] 
**VatNo** | **string** | VAT reg. no. | [optional] 
**ZipCode** | **string** | Zip code | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

