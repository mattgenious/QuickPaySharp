# IO.Swagger.Model.PrivateKey
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_PrivateKey** | **string** | The private key | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

