# IO.Swagger.Model.SubscriptionGroupResult
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | **string** | Error message if anything went wrong, else null | [optional] 
**Status** | **int?** | HTTP status code of recurring enqueue request | [optional] 
**SubscriptionId** | **int?** | Id of subscription | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

