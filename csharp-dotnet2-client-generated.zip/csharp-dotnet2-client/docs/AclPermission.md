# IO.Swagger.Model.AclPermission
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Delete** | **bool?** | Allow DELETE | [optional] 
**Get** | **bool?** | Allow GET | [optional] 
**Patch** | **bool?** | Allow PATCH | [optional] 
**Post** | **bool?** | Allow POST | [optional] 
**Put** | **bool?** | Allow PUT | [optional] 
**Resource** | **string** | Resource URI | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

