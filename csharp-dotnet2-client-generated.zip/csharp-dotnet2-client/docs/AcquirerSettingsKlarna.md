# IO.Swagger.Model.AcquirerSettingsKlarna
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**Eid** | **int?** | Klarna merchant id | [optional] 
**SharedSecret** | **string** | Klarna shared secret | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

