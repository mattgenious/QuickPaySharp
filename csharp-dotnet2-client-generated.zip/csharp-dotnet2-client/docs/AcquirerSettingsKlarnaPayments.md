# IO.Swagger.Model.AcquirerSettingsKlarnaPayments
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**Password** | **string** | Klarna password | [optional] 
**Uid** | **string** | Klarna username | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

