# IO.Swagger.Model.AcquirerSettingsMobilePayOnline
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**DeliveryLimitedTo** | **string** | MobilePayOnline delivery address selection countries limited to | [optional] 
**MerchantId** | **int?** | Id of the merchant | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

