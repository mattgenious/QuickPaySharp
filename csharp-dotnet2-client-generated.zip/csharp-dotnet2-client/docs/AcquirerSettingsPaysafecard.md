# IO.Swagger.Model.AcquirerSettingsPaysafecard
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**Currencies** | **List&lt;string&gt;** | Paysafecard currencies | [optional] 
**Password** | **string** | Paysafecard password | [optional] 
**Username** | **string** | Paysafecard username | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

