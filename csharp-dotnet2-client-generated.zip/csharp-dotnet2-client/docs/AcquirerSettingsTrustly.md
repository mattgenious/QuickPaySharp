# IO.Swagger.Model.AcquirerSettingsTrustly
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**Ideal** | **bool?** | iDeal through Trustly | [optional] 
**Password** | **string** | Trustly API password | [optional] 
**Username** | **string** | Trustly API username | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

