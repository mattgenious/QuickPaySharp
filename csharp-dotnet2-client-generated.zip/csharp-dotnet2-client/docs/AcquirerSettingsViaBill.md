# IO.Swagger.Model.AcquirerSettingsViaBill
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** | True if the acquirer is active | [optional] 
**ApiKey** | **string** | ViaBill api key | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

