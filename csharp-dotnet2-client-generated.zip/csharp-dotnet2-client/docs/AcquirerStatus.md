# IO.Swagger.Model.AcquirerStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acquirer** | **string** | Acquirer | [optional] 
**Health** | **int?** | Health of the acquirer in % | [optional] 
**Status** | **string** | Status of the acquirer. Can be &#39;ok&#39;, &#39;irregular&#39; or &#39;down&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

