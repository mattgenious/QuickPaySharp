# IO.Swagger.Model.AgreementAccount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CallbackUrl** | **string** | Callback URL (Merchant only) | [optional] 
**Id** | **int?** | ID | [optional] 
**Name** | **string** | Name | [optional] 
**ShopName** | **string** | Shop name (Merchant only) | [optional] 
**Type** | **string** | Type of account, e.g. \&quot;Merchant\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

