# IO.Swagger.Model.CardToken
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedAt** | **DateTime?** | Timestamp of creation | [optional] 
**IsUsed** | **bool?** | Token used | [optional] 
**Token** | **string** | Card token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

