# IO.Swagger.Model.FeeFormula
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acquirer** | **string** | Acquirer | [optional] 
**Formula** | **string** | The formula | [optional] 
**PaymentMethod** | **string** | Payment method | [optional] 
**Standard** | **bool?** | True if this is the standard fee formula | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

