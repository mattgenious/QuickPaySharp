# IO.Swagger.Model.IntegrationSettings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Economic** | [**IntegrationSettingsEconomic**](IntegrationSettingsEconomic.md) | e-conomic settings | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

