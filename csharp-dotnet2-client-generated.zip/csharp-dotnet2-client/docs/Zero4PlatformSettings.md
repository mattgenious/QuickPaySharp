# IO.Swagger.Model.Zero4PlatformSettings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Phone** | **string** | 04 merchant phone | [optional] 
**Secret** | **string** | 04 merchant secret | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

